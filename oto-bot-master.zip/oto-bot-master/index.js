const config = require("./config.json");
const { Client, Collection, GatewayIntentBits } = require("discord.js");
const fs = require("fs");
const path = require("path");
const client = new Client({
	intents: [
		GatewayIntentBits.Guilds,
		GatewayIntentBits.GuildMessages,
		GatewayIntentBits.MessageContent,
		GatewayIntentBits.GuildMembers,
	],
});

client.commands = new Collection();
client.commandsArray = [];

const loadFunctions = async () => {
	const functionFolders = await fs.promises.readdir(
		path.join(__dirname, "./functions")
	);
	console.time("Total Function Loading Time");

	const folderLoadPromises = functionFolders.map(async (folder) => {
		console.time(`Reading directory: ${folder}`);
		const functionFiles = await fs.promises.readdir(
			path.join(__dirname, `./functions/${folder}`)
		);
		console.timeEnd(`Reading directory: ${folder}`);

		const fileLoadPromises = functionFiles
			.filter((file) => file.endsWith(".js"))
			.map(async (file) => {
				const filePath = path.join(__dirname, `./functions/${folder}/${file}`);
				console.time(`Loading function: ${file}`);
				if (file === "logAction.js") {
					client.logAction = require(filePath);
				} else if (file === "checkPermissions.js") {
					client.checkPermissions = require(filePath);
				} else {
					require(filePath)(client);
				}
				console.timeEnd(`Loading function: ${file}`);
			});

		await Promise.all(fileLoadPromises);
	});

	await Promise.all(folderLoadPromises);
	console.timeEnd("Total Function Loading Time");
};

const initBot = async () => {
	console.time("Total Initialization Time");

	console.time("Function Loading");
	await loadFunctions();
	console.timeEnd("Function Loading");

	console.time("Event Handling");
	client.handleEvents();
	console.timeEnd("Event Handling");

	console.time("Command Handling");
	client.handleCommands();
	console.timeEnd("Command Handling");

	console.time("Client Login");
	await client.login(config.token);
	console.timeEnd("Client Login");

	console.timeEnd("Total Initialization Time");
};

initBot()
	.then(() => {
		console.log("Bot initialization completed.");
	})
	.catch((err) => {
		console.error("Error during bot initialization:", err);
	});
