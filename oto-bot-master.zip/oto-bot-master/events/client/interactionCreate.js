module.exports = {
	name: "interactionCreate",
	async execute(interaction, client) {
		if (!interaction.isChatInputCommand()) return;
		const command = interaction.client.commands.get(interaction.commandName);

		if (!command) {
			if (interaction.deferred || interaction.replied) {
				await interaction.editReply({
					content: "This command does not exist",
					ephemeral: true,
				});
			} else {
				await interaction.reply({
					content: "This command does not exist",
					ephemeral: true,
				});
			}
		}

		try {
			await command.execute(interaction, client);
		} catch (error) {
			console.error(
				`❌ Error while executing command ${interaction.commandName}: ${error}`
			);
			if (interaction.deferred || interaction.replied) {
				await interaction.editReply({
					content: `There was an error while executing this command\n\n> \`${error.message}\``,
					ephemeral: true,
				});
			} else {
				await interaction.reply({
					content: `There was an error while executing this command\n\n> \`${error.message}\``,
					ephemeral: true,
				});
			}
		}
	},
};
