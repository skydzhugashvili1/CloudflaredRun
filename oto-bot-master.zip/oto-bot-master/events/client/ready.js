const { ActivityType } = require("discord.js");

module.exports = {
	name: "ready",
	once: true,
	execute(client) {
		try {
			console.log(`✅ ${client.user.tag} is ready!`);
			client.user.setStatus("online");
			client.user.setActivity("OverTheOcean Community", {
				type: ActivityType.Watching,
			});
			console.log("🚀 Status set successfully.");
		} catch (error) {
			console.error("❌ Error setting status:", error);
		}
	},
};
