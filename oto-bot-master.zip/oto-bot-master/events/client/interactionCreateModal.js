const { MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../config.json");
const { logAction } = require("../../functions/utility/logAction");

module.exports = {
	name: "interactionCreate",
	async execute(interaction, client) {
		if (!interaction.isModalSubmit()) return;

		/**
		 * #########################
		 *        announcement modal
		 * ##########################
		 */

		if (interaction.customId.includes("announcementModal_")) {
			const announcementChannelId = interaction.customId.split("_")[1];
			const announcementChannel = await interaction.guild.channels.fetch(
				announcementChannelId
			);
			const pingEveryone = interaction.customId.split("_")[2];

			const announcementMessage = interaction.fields.getTextInputValue(
				"announcementMessage"
			);

			await interaction.deferReply({ ephemeral: true });

			const announcement = await announcementChannel.send({
				content: announcementMessage,
			});
			for (const message of config.announcementMessage) {
				await announcementChannel.send({
					content: message,
				});
			}

			if (pingEveryone === "true") {
				await announcementChannel
					.send({
						content: "@everyone",
					})
					.then((msg) => msg.delete());
			}

			await interaction.editReply({
				content: "Announcement sent!",
			});

			await interaction.client.logAction(
				"Announcement",
				`<@${interaction.user.id}> made a announcement at ${announcement.url}.`,
				interaction
			);
		}
	},
};
