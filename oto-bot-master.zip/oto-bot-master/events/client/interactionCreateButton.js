const { MessageActionRow, MessageButton } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	name: "interactionCreate",
	async execute(interaction, client) {
		if (!interaction.isButton()) return;
	},
};
