const { SlashCommandBuilder } = require("discord.js");
const config = require("../../config.json");

async function logAction(actionTitle, actionDescription, user) {
	const logsChannel = await user.guild.channels.fetch(config.logsChannelId);

	const logEmbed = {
		color: 0x0099ff,
		title: actionTitle,
		description: actionDescription,
		timestamp: new Date(),
		footer: {
			text: `User: ${user.user.tag} | User ID: ${user.user.id}`,
			icon_url: user.user.displayAvatarURL({ dynamic: true }),
		},
	};

	await logsChannel.send({ embeds: [logEmbed] });
}

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("kick")
		.setDescription("Kicks a member.")
		.addUserOption((option) =>
			option
				.setName("target")
				.setDescription("The member to kick.")
				.setRequired(true)
		)
		.addStringOption((option) =>
			option
				.setName("reason")
				.setDescription("The reason for kicking the member.")
				.setRequired(false)
		),
	async execute(interaction, client) {
		const target = interaction.options.getMember("target", true);
		const reason =
			interaction.options.getString("reason") || "No reason provided.";

		await interaction.deferReply({ ephemeral: true });

		if (
			(await client.checkPermissions(config.adminRoleId, interaction)) === false
		) {
			return await interaction.editReply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});
		}

		if (
			target.roles.highest.position >= interaction.member.roles.highest.position
		) {
			return await interaction.editReply({
				content: "You cannot kick a member with a higher role than you!",
				ephemeral: true,
			});
		}

		if (
			target.roles.highest.position >=
			interaction.guild.me.roles.highest.position
		) {
			return await interaction.editReply({
				content: "I cannot kick a member with a higher role than me!",
				ephemeral: true,
			});
		}

		if (target.id === interaction.guild.me.id) {
			return await interaction.editReply({
				content: "I cannot kick myself!",
				ephemeral: true,
			});
		}

		try {
			await target.kick(reason);
			await interaction.editReply({
				content: `Successfully kicked ${target.user.tag}!`,
				ephemeral: true,
			});
			await logAction(
				"Kick",
				`Kicked ${target.user.tag} for: ${reason}`,
				interaction
			);
		} catch (error) {
			console.error(error);
			await interaction.editReply({
				content: `There was an error while kicking ${target.user.tag}:\n\`${error.message}\``,
				ephemeral: true,
			});
		}
	},
};
