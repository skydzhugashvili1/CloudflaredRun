const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("purge")
		.setDescription("Purge messages in a channel.")
		.addSubcommand((subcommand) =>
			subcommand
				.setName("all")
				.setDescription("Purge all messages in a channel.")
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("amount")
				.setDescription("Purge a specific amount of messages.")
				.addIntegerOption((option) =>
					option
						.setName("amount")
						.setDescription("Amount of messages to purge.")
						.setRequired(true)
				)
		),

	async execute(interaction, client) {
		if (
			(await client.checkPermissions(config.adminRoleId, interaction)) === false
		) {
			return await interaction.reply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});
		} else {
			if (interaction.options.getSubcommand() === "all") {
				await interaction.deferReply({
					fetchReply: true,
					ephemeral: true,
				});
				await interaction.editReply({
					content: "Purging all messages...",
				});
				while (true) {
					const messages = await interaction.channel.messages.fetch({
						limit: 100,
					});
					if (messages.size === 0) {
						break;
					} else {
						await interaction.channel.bulkDelete(messages.size, true);
					}
				}
				const logsChannel = await client.channels.fetch(config.logsChannelId);

				const logEmbed = new EmbedBuilder()
					.setTitle("Purge All")
					.setDescription(
						`All messages have been purged in <#${interaction.channel.id}>.`
					)
					.setColor(parseInt(`0x${config.embedColor}`))
					.setTimestamp(Date.now())
					.setAuthor({
						name: interaction.guild.name,
						iconURL: interaction.guild.iconURL(),
					})
					.setFooter({
						text: `Action by ${interaction.user.tag} | User ID: ${interaction.user.id}`,
						iconURL: interaction.user.avatarURL(),
					});
				logsChannel.send({ embeds: [logEmbed] });
				await interaction.editReply({
					embeds: [logEmbed],
					content: "",
				});
			} else if (interaction.options.getSubcommand() === "amount") {
				const amount = interaction.options.getInteger("amount");

				if (amount > 100) {
					return await interaction.reply({
						content: "You cannot delete more than 100 messages at once!",
						ephemeral: true,
					});
				}
				if (amount < 1) {
					return await interaction.reply({
						content: "You must delete at least one message!",
						ephemeral: true,
					});
				}
				await interaction.deferReply({
					fetchReply: true,
					ephemeral: true,
				});
				await interaction.editReply({
					content: `Purging ${amount} messages...`,
				});
				const messages = await interaction.channel.messages.fetch({
					limit: amount,
				});
				// If there is a 14+ day old message in the messages to be deleted, it will throw an error.
				const currentTimestamp = Date.now();
				const fourteenDaysAgo = currentTimestamp - 1209600000;
				const fourteenDaysAgoMessage = messages.find(
					(message) => message.createdTimestamp < fourteenDaysAgo
				);
				if (fourteenDaysAgoMessage) {
					return await interaction.editReply({
						content: "You cannot delete messages older than 14 days!",
					});
				}
				await interaction.channel.bulkDelete(messages.size, true);
				const logsChannel = await client.channels.fetch(config.logsChannelId);

				const logEmbed = new EmbedBuilder()
					.setTitle("Purge")
					.setDescription(
						`${amount} messages have been purged in <#${interaction.channel.id}>.`
					)
					.setColor(parseInt(`0x${config.embedColor}`))
					.setTimestamp(Date.now())
					.setAuthor({
						name: interaction.guild.name,
						iconURL: interaction.guild.iconURL(),
					})
					.setFooter({
						text: `Action by ${interaction.user.tag} | User ID: ${interaction.user.id}`,
						iconURL: interaction.user.avatarURL(),
					});
				logsChannel.send({ embeds: [logEmbed] });
				await interaction.editReply({
					embeds: [logEmbed],
					content: "",
				});
			}
		}
	},
};
