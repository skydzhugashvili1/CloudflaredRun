const { SlashCommandBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("untimeout")
		.setDescription("untimeout a user.")
		.addUserOption((option) =>
			option
				.setName("user")
				.setDescription("The user to untimeout.")
				.setRequired(true)
		)

		.addStringOption((option) =>
			option
				.setName("reason")
				.setDescription("The reason for the untimeout.")
				.setRequired(false)
		),
	async execute(interaction, client) {
		await interaction.reply("This command is not yet implemented.");
		/*
    await interaction.deferReply({ ephemeral: true });
    if (!(await client.checkPermissions(config.moderatorRoleId, interaction))) {
      return interaction.editReply({
        content: "You do not have permission to use this command!",
        ephemeral: true,
      });
    }
    const user = interaction.options.getUser("user");
    const reason =
      interaction.options.getString("reason") || "No reason provided.";
    const member = await interaction.guild.members.fetch(user.id);

    if (
      member.roles.highest.position >=
      interaction.guild.me.roles.highest.position
    ) {
      return interaction.editReply({
        content: "I cannot untimeout a user with a higher role than me!",
        ephemeral: true,
      });
    }

    if (
      member.roles.highest.position >= interaction.member.roles.highest.position
    ) {
      return interaction.editReply({
        content: "You cannot untimeout a user with a higher role than you!",
        ephemeral: true,
      });
    }

    if (member.id === interaction.guild.me.id) {
      return interaction.editReply({
        content: "I cannot untimeout myself!",
        ephemeral: true,
      });
    }

    if (member.id === interaction.user.id) {
      return interaction.editReply({
        content: "You cannot untimeout yourself!",
        ephemeral: true,
      });
    }

    try {
      await member.timeout(duration * 60000, reason);
      await interaction.editReply({
        content: `Successfully un-timedout <@${member.id}> for ${duration} minutes.`,
      });

      await client.logAction(
        interaction.guild,
        "Timeout",
        `User <@${member.id}> was un-timedout by ${interaction.user.tag} for ${duration} minutes.`
      );
    } catch (error) {
      console.error(error);
      await interaction.editReply({
        content: "An error occurred while trying to untimeout the user.",
        ephemeral: true,
      });
    }
    */
	},
};
