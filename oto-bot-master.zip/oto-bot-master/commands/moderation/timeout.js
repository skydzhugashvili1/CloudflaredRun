const { SlashCommandBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("timeout")
		.setDescription("Timeout a user.")
		.addUserOption((option) =>
			option
				.setName("user")
				.setDescription("The user to timeout.")
				.setRequired(true)
		)
		.addIntegerOption((option) =>
			option
				.setName("duration")
				.setDescription("The duration of the timeout in minutes.")
				.setRequired(true)
		)
		.addStringOption((option) =>
			option
				.setName("reason")
				.setDescription("The reason for the timeout.")
				.setRequired(false)
		),
	async execute(interaction, client) {
		await interaction.deferReply({ ephemeral: true });
		if (!(await client.checkPermissions(config.moderatorRoleId, interaction))) {
			return interaction.editReply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});
		}
		const user = interaction.options.getUser("user");
		const duration = interaction.options.getInteger("duration");
		const reason =
			interaction.options.getString("reason") || "No reason provided.";
		const member = await interaction.guild.members.fetch(user.id);

		if (
			member.roles.highest.position >=
			interaction.guild.me.roles.highest.position
		) {
			return interaction.editReply({
				content: "I cannot timeout a user with a higher role than me!",
				ephemeral: true,
			});
		}

		if (
			member.roles.highest.position >= interaction.member.roles.highest.position
		) {
			return interaction.editReply({
				content: "You cannot timeout a user with a higher role than you!",
				ephemeral: true,
			});
		}

		if (member.id === interaction.guild.me.id) {
			return interaction.editReply({
				content: "I cannot timeout myself!",
				ephemeral: true,
			});
		}

		if (member.id === interaction.user.id) {
			return interaction.editReply({
				content: "You cannot timeout yourself!",
				ephemeral: true,
			});
		}

		if (duration > 40320) {
			return interaction.editReply({
				content: "The maximum duration for a timeout is 28 days.",
				ephemeral: true,
			});
		}
		try {
			await member.timeout(duration * 60000, reason);
			await interaction.editReply({
				content: `Successfully timed out <@${member.id}> for ${duration} minutes.`,
			});

			await client.logAction(
				interaction.guild,
				"Timeout",
				`User <@${member.id}> was timed out by ${interaction.user.tag} for ${duration} minutes.`
			);
		} catch (error) {
			console.error(error);
			await interaction.editReply({
				content: "An error occurred while trying to timeout the user.",
				ephemeral: true,
			});
		}
	},
};
