const {
	SlashCommandBuilder,
	ChatInputCommandInteraction,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("role")
		.setDescription("Gives or removes a role from a user")
		.addUserOption((option) =>
			option
				.setName("user")
				.setDescription("The User To Give The Role")
				.setRequired(true)
		)
		.addRoleOption((option) =>
			option.setName("role").setDescription("The Role").setRequired(true)
		),
	async execute(interaction, client) {
		await interaction.deferReply({ ephemeral: true });

		const executorIsOwner = config.ownershipIds.includes(interaction.user.id);

		if (
			!executorIsOwner &&
			!(await client.checkPermissions(config.adminRoleId, interaction))
		) {
			return interaction.editReply({
				content: `You do not have the required permissions to use this command.`,
			});
		}

		const role = interaction.options.getRole("role");
		const member = await interaction.guild.members.fetch(
			interaction.options.getUser("user").id
		);

		// Check if the role position is higher than the bot's highest role
		if (role.position >= interaction.guild.members.me.roles.highest.position) {
			return interaction.editReply({
				content: `I cannot add a role higher than my highest role.`,
			});
		}

		if (!executorIsOwner) {
			// Check if the user executing the command has a higher role position
			if (role.position >= interaction.member.roles.highest.position) {
				return interaction.editReply({
					content: `You cannot add a role higher than your highest role.`,
				});
			}

			// Prevent adding or removing roles to/from the bot itself
			if (member.id === interaction.guild.members.me.id) {
				return interaction.editReply({
					content: `I cannot add a role to myself.`,
				});
			}

			// Ensure the executor has a higher role than the target member
			if (
				member.roles.highest.position >=
				interaction.member.roles.highest.position
			) {
				return interaction.editReply({
					content: `You cannot add a role to someone with a higher or equal role position to you.`,
				});
			}
		}

		// Toggle the role for the target member
		if (member.roles.cache.has(role.id)) {
			await member.roles.remove(role);
			interaction.editReply({
				content: `Successfully removed <@&${role.id}> from <@${member.id}>`,
			});
			await client.logAction(
				`Role Removed`,
				`Role <@&${role.id}> was removed from ${member.user.tag} by ${interaction.user.tag}`,
				interaction
			);
		} else {
			await member.roles.add(role);
			interaction.editReply({
				content: `Successfully added <@&${role.id}> to <@${member.id}>`,
			});
			await client.logAction(
				`Role Added`,
				`Role <@&${role.id}> was added to ${member.user.tag} by ${interaction.user.tag}`,
				interaction
			);
		}
	},
};
