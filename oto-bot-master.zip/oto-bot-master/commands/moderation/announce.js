const {
	SlashCommandBuilder,
	EmbedBuilder,
	ModalBuilder,
	ActionRowBuilder,
	TextInputBuilder,
	TextInputStyle,
} = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "moderation",
	data: new SlashCommandBuilder()
		.setName("announce")
		.setDescription("Announce a message in a channel.")
		.addChannelOption((option) =>
			option
				.setName("channel")
				.setDescription("Channel to announce in.")
				.setRequired(true)
		)
		.addBooleanOption((option) =>
			option.setName("ping").setDescription("Ping everyone.").setRequired(false)
		),
	async execute(interaction, client) {
		if (
			(await client.checkPermissions(
				config.publicRelationsRoleId,
				interaction
			)) === false
		) {
			return await interaction.reply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});
		} else {
			let modal;
			if (interaction.options.getBoolean("ping")) {
				modal = new ModalBuilder()
					.setTitle("Announcement")
					.setCustomId(
						`announcementModal_${
							interaction.options.getChannel("channel").id
						}_${interaction.options.getBoolean("ping")}`
					);
			} else {
				modal = new ModalBuilder()
					.setTitle("Announcement")
					.setCustomId(
						`announcementModal_${
							interaction.options.getChannel("channel").id
						}_false`
					);
			}
			const announcementMessage = new TextInputBuilder()
				.setLabel("Message to announce.")
				.setPlaceholder("Enter your message here.")
				.setCustomId("announcementMessage")
				.setStyle(TextInputStyle.Paragraph)
				.setRequired(true);

			modal.addComponents(
				new ActionRowBuilder().addComponents(announcementMessage)
			);

			await interaction.showModal(modal);
		}
	},
};
