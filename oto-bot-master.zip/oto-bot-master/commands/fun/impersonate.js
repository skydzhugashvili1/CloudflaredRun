const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "fun",
	data: new SlashCommandBuilder()
		.setName("impersonate")
		.setDescription("Impersonate a user.")
		.addUserOption((option) =>
			option
				.setName("user")
				.setDescription("The user to impersonate.")
				.setRequired(true)
		)
		.addStringOption((option) =>
			option
				.setName("message")
				.setDescription("The message to send.")
				.setRequired(true)
		),
	async execute(interaction, client) {
		await interaction.deferReply({ ephemeral: true });
		const webhooks = await interaction.channel.fetchWebhooks();
		let impersonateWebhook = webhooks.find(
			(webhook) =>
				webhook.name === "Impersonate" && webhook.owner.id === client.user.id
		);
		if (!impersonateWebhook) {
			console.log("Creating webhook");
			impersonateWebhook = await interaction.channel.createWebhook({
				name: "Impersonate",
			});
		}

		const user = interaction.options.getUser("user");
		const impersonateUserProfilePicture = user.displayAvatarURL({
			dynamic: true,
		});
		const impersonateUsername = user.displayName;

		await impersonateWebhook.send({
			content: interaction.options.getString("message"),
			username: impersonateUsername,
			avatarURL: impersonateUserProfilePicture,
			allowedMentions: { parse: ["users", "roles"] },
		});

		await interaction.editReply({
			content: `Message sent as ${user.tag}.`,
			ephemeral: true,
		});
	},
};
