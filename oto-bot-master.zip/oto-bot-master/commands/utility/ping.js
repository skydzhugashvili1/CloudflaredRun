const { SlashCommandBuilder, EmbedBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "utility",
	data: new SlashCommandBuilder()
		.setName("ping")
		.setDescription("Returns bot latency and uptime"),
	async execute(interaction, client) {
		const message = await interaction.deferReply({
			fetchReply: true,
		});
		const uptime = client.uptime;
		const days = Math.floor(uptime / 86400000);
		const hours = Math.floor(uptime / 3600000) % 24;
		const minutes = Math.floor(uptime / 60000) % 60;
		const seconds = Math.floor(uptime / 1000) % 60;
		embed = new EmbedBuilder()
			.setTitle("Pong!")
			.addFields([
				{
					name: "Bot Latency",
					value: `**${
						message.createdTimestamp - interaction.createdTimestamp
					}ms**`,
					inline: true,
				},
				{
					name: "API Latency",
					value: `**${client.ws.ping}ms**`,
					inline: true,
				},
				{
					name: "Uptime",
					value: `\`\`\`fix\n${days}d ${hours}h ${minutes}m ${seconds}s\`\`\``,
					inline: false,
				},
			])
			.setColor(parseInt(`0x${config.embedColor}`))
			.setTimestamp(Date.now())
			.setAuthor({
				name: interaction.guild.name,
				iconURL: interaction.guild.iconURL(),
			})
			.setFooter({
				text: `Requested by ${interaction.user.tag}`,
				iconURL: interaction.user.avatarURL(),
			});
		await interaction.editReply({ embeds: [embed] });
	},
};
