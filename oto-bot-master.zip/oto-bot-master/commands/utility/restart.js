const { SlashCommandBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "utility",
	data: new SlashCommandBuilder()
		.setName("restart")
		.setDescription("Restarts the bot."),
	async execute(interaction, client) {
		if (!config.devIds.includes(interaction.user.id)) {
			return interaction.reply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});
		}

		await interaction.reply("Restarting...");

		await client.destroy();
		process.exit();
	},
};
