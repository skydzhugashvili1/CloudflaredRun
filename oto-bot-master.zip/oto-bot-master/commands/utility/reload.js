const { SlashCommandBuilder } = require("discord.js");
const config = require("../../config.json");

module.exports = {
	category: "utility",
	data: new SlashCommandBuilder()
		.setName("reload")
		.setDescription("Reloads command(s).")
		.addSubcommand((subcommand) =>
			subcommand.setName("all").setDescription("Reloads all commands.")
		)
		.addSubcommand((subcommand) =>
			subcommand
				.setName("command")
				.setDescription("Reloads a specific command.")
				.addStringOption((option) =>
					option
						.setName("command")
						.setDescription("The command to reload.")
						.setRequired(true)
				)
		),
	async execute(interaction, client) {
		if (!config.devIds.includes(interaction.user.id))
			return interaction.reply({
				content: "You do not have permission to use this command!",
				ephemeral: true,
			});

		if (interaction.options.getSubcommand() === "all") {
			client.commands.forEach((command) => {
				if (command.data.name === "reload") return;
				delete require.cache[
					require.resolve(`../${command.category}/${command.data.name}.js`)
				];
				try {
					const newCommand = require(`../${command.category}/${command.data.name}.js`);
					client.commands.set(newCommand.data.name, newCommand);
				} catch (error) {
					console.error(error);
					return interaction.reply({
						content: `There was an error while reloading a command \`${command.data.name}\`:\n\`${error.message}\``,
						ephemeral: true,
					});
				}
			});
			return interaction.reply({
				content: "All commands were reloaded!",
				ephemeral: true,
			});
		} else {
			const commandName = interaction.options
				.getString("command", true)
				.toLowerCase();
			const command = client.commands.get(commandName);

			if (!command) {
				return interaction.reply({
					content: `There is no command with name \`${commandName}\`!`,
					ephemeral: true,
				});
			}

			if (command.data.name === "reload") {
				return interaction.reply({
					content: "You cannot reload this command!",
					ephemeral: true,
				});
			}

			delete require.cache[
				require.resolve(`../${command.category}/${command.data.name}.js`)
			];

			try {
				client.commands.delete(command.data.name);
				const newCommand = require(`../${command.category}/${command.data.name}.js`);
				client.commands.set(newCommand.data.name, newCommand);
				return interaction.reply({
					content: `Command \`${newCommand.data.name}\` was reloaded!`,
					ephemeral: true,
				});
			} catch (error) {
				console.error(error);
				return interaction.reply({
					content: `There was an error while reloading a command \`${command.data.name}\`:\n\`${error.message}\``,
					ephemeral: true,
				});
			}
		}
	},
};
