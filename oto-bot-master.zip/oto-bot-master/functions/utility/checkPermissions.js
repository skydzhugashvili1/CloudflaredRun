module.exports = async function checkPermissions(minimumRoleId, interaction) {
	let guild = await interaction.client.guilds.fetch(interaction.guildId);
	let member = await guild.members.fetch(interaction.user.id);

	const minimumRole = await guild.roles.fetch(minimumRoleId);
	const serverRoles = await guild.roles.fetch();
	const userRoles = member.roles.cache;
	if (
		!userRoles.has(minimumRole.id) &&
		!serverRoles.some(
			(serverRole) => serverRole.position > minimumRole.position
		)
	) {
		return false;
	} else {
		return true;
	}
};
