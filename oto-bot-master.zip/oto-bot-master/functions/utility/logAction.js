const config = require("../../config.json");

module.exports = async function logAction(
	actionTitle,
	actionDescription,
	interaction
) {
	const logsChannel = await interaction.guild.channels.fetch(
		config.logsChannelId
	);

	const logEmbed = {
		color: 0x0099ff,
		title: actionTitle,
		description: actionDescription,
		timestamp: new Date(),
		footer: {
			text: `User: ${interaction.user.tag} | User ID: ${interaction.user.id}`,
			icon_url: interaction.user.displayAvatarURL({ dynamic: true }),
		},
	};

	await logsChannel.send({ embeds: [logEmbed] });
};
