const fs = require("fs");
const { REST } = require("@discordjs/rest");
const { Routes } = require("discord-api-types/v9");
const config = require("../../config.json");

module.exports = (client) => {
	client.handleCommands = async () => {
		const commandFolders = fs.readdirSync("./commands");
		for (const folder of commandFolders) {
			const commandFiles = fs
				.readdirSync(`./commands/${folder}`)
				.filter((file) => file.endsWith(".js"));

			const { commands, commandsArray } = client;
			for (const file of commandFiles) {
				const command = require(`../../commands/${folder}/${file}`);
				commands.set(command.data.name, command);
				commandsArray.push(command.data.toJSON());
				console.log(`🛠️  Command: ${command.data.name} loaded!`);
			}
		}

		const rest = new REST({ version: "9" }).setToken(config.token);
		try {
			await rest.put(
				Routes.applicationGuildCommands(config.clientId, config.guildId),
				{
					body: client.commandsArray,
				}
			);

			console.log("✅ Successfully reloaded application (/) commands.");
		} catch (error) {
			console.error(
				`❌ Error while refreshing application (/) commands: ${error}`
			);
		}
	};
};
